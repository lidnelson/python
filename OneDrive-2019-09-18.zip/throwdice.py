import dice

def throw():
	print(dice.rangen())
	