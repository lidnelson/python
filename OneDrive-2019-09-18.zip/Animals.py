animal1 = input("Type an animal here: ")
animal2 = input("Type an animal here: ")

if animal1 < animal2:
	print("the animal that comes first alphabetically is:", animal1)
else:
	print("the animal that comes first alphabetically is", animal2)