number1 = float(input("enter number here: "))
number2 = float(input("enter number here: "))
answer = number1*number2
print(float(answer))
print(int(answer))