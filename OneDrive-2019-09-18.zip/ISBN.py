ISBN = 978-0-306-40615
#ISBN = list(input("enter ISBN number here: "))

#if len(ISBN) != 12:
	#print("Check the number")
	#ISBN = list(input("enter ISBN number here: "))
#print()



