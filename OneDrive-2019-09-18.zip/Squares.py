for i in range(1,100):
	if i**2<2000
	print(i, "squared", i**"")