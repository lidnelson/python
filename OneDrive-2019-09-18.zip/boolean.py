number1 = float(input("enter number here: "))
number2 = float(input("enter number here: "))

if number1>number2:
	number1bigger= True
else:
	number1bigger= False

print ("number1bigger", number1bigger)