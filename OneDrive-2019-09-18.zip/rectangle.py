ShortSide= float(input("Please type the length of the short side: "))#here some one puts in the length of the shortest side of the rectangle
LongSide= float(input("Please type the length of the long side: "))

Perimeter1 = ShortSide + ShortSide + LongSide + LongSide
Area = ShortSide*LongSide
print ("preimeter =",Perimeter1)
print ("area =", Area)
# don't forget to put comments in your code!