Sports = ["football", "rugby", "cricket", "darts"]
Sports.append ("basketball")
Sports.append ("baseball")
Sports.append ("golf")
Sports.insert (0,"softball")
del Sports[4]
print(Sports[0:5])