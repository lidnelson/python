number1 = float(input("please enter first number here: "))
number2 = float(input( "please enter second number here: "))
answer = number1 % number2
print(answer)