#########
## ## ###
#       E
#### ####
#### ####
####    #
###### ##
###### ##
####>  ##
#########
mazerows= int(input("how many rows of the maze do you want?"))

while mazerows> 0:
	x=range(mazerows)
	input("Row" x:)
print()

