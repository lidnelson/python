number1= float(input("insert first number here: "))
number2 = float(input("insert second number here: "))
answer = number1 - number2
print(number1, "-", number2, "=", answer)
