def rounddown(n,m):
	if n%m != 0:
		print(round(n/m)-1)
	else:
		print(n/m)

