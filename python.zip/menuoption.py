print("Menu")
print("1 - Add")
print("2 - Amned")
print("3 - Delete")
print("4 - Display")

menu_option = int(input("Enter option: "))
if menu_option == 1:
	print("Option 1 - Add selection")
if menu_option == 2:
	print("Option 2 - Amend selected")
if menu_option == 3:
	print("Option 3 - Delete selected")
if menu_option == 4:
	print("Option 4 - Display selected")