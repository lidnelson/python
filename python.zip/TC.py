file= open("filename.txt","a")

file.seek(0)
file.write("This is a new line \n")



file.close()