import random

def rangen():
	return random.randint(1,6)

for i in range(2):
	print (rangen())
