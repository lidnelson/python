yellowpages ={
	'Tom': 7865432457,
	'Charlotte': 7432775284,
	'Jessie': 7886854532,
	'Oliver': 7864534257,
	'James': 7845345349,
	'Joe': 7864357624,
	'Terry': 7645232453,
	'Trevor':7842362883,
	'Charlie': 7526637829,
	'Max': 73435635256,
	'Alex': 7856357725,
	'Ray': 7562526617,
	'Rory': 7352534737,
	'Harry': 7364526342,
	'Larry': 7325546276,
	'Bob': 7634527634,
	'Andrew': 7425356463,
	'Jason': 7532454356,
	'Bella': 7532455366,
	'Chloe': 7526634417
}
print(yellowpages)

list_of_keys= list(yellowpages.keys())
list_of_keys2 =list(yellowpages.values())

print(list_of_keys2[1:19:2])
print(list_of_keys[14:19])
